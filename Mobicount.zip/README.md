### Installs

- Install python 3.12 -> https://www.python.org/downloads/release/python-3120/ 
- Other python compatible versions (3.13) 
- Accept every request from python installer
- Install your favorite python IDE 
  - Pycharm -> https://www.jetbrains.com/pycharm/download/?section=windows
- Install ffmpeg
  - Open terminal
    - On windows : winget install ffmpeg
    - On mac : brew install ffmpeg



### FFMPEG

- Remove audio canal: 
  - ffmpeg -i input.mp4 -c:v copy -an output.mp4
  - for f in *.mp4; do ffmpeg -i "$f" -c:v copy -an "../no-audio_${f}"; done (bash)
  - for %f in (*.mp4) do ffmpeg -i "%f" -c:v copy -an "../no-audio_%f" (windows CMD)
- Filter fps: ffmpeg -i input.mp4 -filter:v "fps=30" output.mp4
- Get 30 first seconds: ffmpeg -i input.mp4 -t 30 -c copy output.mp4
- Rename to from *.MP4 to *.mp4 : 
  - for f in *.MP4; do mv "$f" "${f%.MP4}.mp4"; done (bash)
- Resize to hd
  - for %f in (*.mp4) do ffmpeg -i "%f" -vf scale=1920:-2 -c:v libx264 -crf 23 -preset fast -c:a copy "../%~nf_HD.mp4"
  - foreach ($f in Get-ChildItem *.mp4) { ffmpeg -i $f.FullName -vf "scale=1920:-2" -c:v libx264 -crf 23 -preset fast -c:a copy "..\$($f.BaseName)_HD.mp4" } (WINDOWS POWERSHELL)






### Create Python Environement and run on Windows (CMD)

- At MobiCount\..
- PYTHON_PATH\python.exe -m venv .venv
- .venv\Scripts\activate.bat
- pip install -r MobiCount\requirements.txt




